package state;

public class Estado {
}
